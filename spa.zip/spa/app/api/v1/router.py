from fastapi import APIRouter

api_router = APIRouter()

# En las siguientes fases registraremos aqui los routers de:
# auth, clientes, empleados, procedimientos, citas, tratamientos, etc.